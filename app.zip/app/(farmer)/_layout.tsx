import { Stack } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { Slot } from 'expo-router';
import { View, Text } from 'react-native';

export default function FarmerLayout() {
  const { user } = useAuth();

  if (!user || user.role !== 'farmer') {
    return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Unauthorized. Please login as a farmer.</Text>
    </View>;
  }

  return <Slot />;
} 