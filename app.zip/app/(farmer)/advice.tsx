import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, usePathname } from 'expo-router';

interface Consultation {
  id: string;
  topic: string;
  description: string;
  cropType: string;
  status: 'Pending' | 'In Progress' | 'Resolved';
  expert?: string;
  createdAt: string;
  lastUpdate: string;
  messages: Message[];
}

interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
  isExpert: boolean;
}

const initialConsultations: Consultation[] = [
  {
    id: '1',
    topic: 'Tomato Leaf Disease',
    description: 'Yellow spots appearing on tomato leaves, need advice on treatment.',
    cropType: 'Tomatoes',
    status: 'In Progress',
    expert: 'Dr. Sarah Johnson',
    createdAt: '2024-03-15',
    lastUpdate: '2024-03-16',
    messages: [
      {
        id: '1',
        sender: 'Farmer',
        content: 'I noticed yellow spots on my tomato leaves this morning. What could it be?',
        timestamp: '2024-03-15 09:00',
        isExpert: false,
      },
      {
        id: '2',
        sender: 'Dr. Sarah Johnson',
        content: 'Based on your description, it might be early blight. Could you share a photo of the affected leaves?',
        timestamp: '2024-03-16 10:30',
        isExpert: true,
      },
    ],
  },
  {
    id: '2',
    topic: 'Soil Testing',
    description: 'Need guidance on soil pH levels for corn cultivation',
    cropType: 'Corn',
    status: 'Pending',
    createdAt: '2024-03-16',
    lastUpdate: '2024-03-16',
    messages: [],
  },
];

const navItems = [
  { name: 'Dashboard', icon: 'home', route: '/(farmer)/' },
  { name: 'Market', icon: 'cart', route: '/(farmer)/market' },
  { name: 'Chat', icon: 'chatbubbles', route: '/(farmer)/advice' },
  { name: 'Profile', icon: 'person', route: '/(farmer)/profile' },
];

export default function AdviceScreen() {
  const router = useRouter();
  const pathname = usePathname();
  const [consultations, setConsultations] = useState<Consultation[]>(initialConsultations);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedConsultation, setSelectedConsultation] = useState<Consultation | null>(null);
  const [newConsultation, setNewConsultation] = useState<Partial<Consultation>>({});
  const [newMessage, setNewMessage] = useState('');

  const handleAddConsultation = () => {
    if (newConsultation.topic && newConsultation.description && newConsultation.cropType) {
      const consultation: Consultation = {
        id: Date.now().toString(),
        topic: newConsultation.topic,
        description: newConsultation.description,
        cropType: newConsultation.cropType,
        status: 'Pending',
        createdAt: new Date().toISOString().split('T')[0],
        lastUpdate: new Date().toISOString().split('T')[0],
        messages: [],
      };
      setConsultations([...consultations, consultation]);
      setModalVisible(false);
      setNewConsultation({});
    }
  };

  const handleSendMessage = () => {
    if (selectedConsultation && newMessage.trim()) {
      const message: Message = {
        id: Date.now().toString(),
        sender: 'Farmer',
        content: newMessage,
        timestamp: new Date().toLocaleString(),
        isExpert: false,
      };
      const updatedConsultation = {
        ...selectedConsultation,
        messages: [...selectedConsultation.messages, message],
        lastUpdate: new Date().toISOString().split('T')[0],
      };
      setConsultations(
        consultations.map((c) =>
          c.id === selectedConsultation.id ? updatedConsultation : c
        )
      );
      setNewMessage('');
      setSelectedConsultation(updatedConsultation);
    }
  };

  const getStatusColor = (status: Consultation['status']) => {
    switch (status) {
      case 'Pending':
        return '#FFA000';
      case 'In Progress':
        return '#4CAF50';
      case 'Resolved':
        return '#2196F3';
      default:
        return '#666';
    }
  };

  const handleNavigation = (route: string) => {
    router.push(route);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Agricultural Advice</Text>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.message}>This is the advice screen.</Text>
        
        <TouchableOpacity 
          style={styles.button}
          onPress={() => router.push('/(farmer)/')}
        >
          <Text style={styles.buttonText}>Back to Dashboard</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#4CAF50',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    marginRight: 15,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  message: {
    fontSize: 18,
    marginBottom: 30,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 6,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
}); 