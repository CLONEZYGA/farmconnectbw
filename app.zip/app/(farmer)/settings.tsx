// 🔁 Enhanced SettingsScreen with improved UI and fixed signOut functionality

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Switch,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, usePathname } from 'expo-router';
import { useAuth } from '../../context/AuthContext';

interface FarmDetails {
  name: string;
  location: string;
  size: string;
  mainCrops: string[];
  yearEstablished: string;
}

interface FarmerProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  farmDetails: FarmDetails;
  notificationSettings: {
    marketUpdates: boolean;
    weatherAlerts: boolean;
    expertAdvice: boolean;
    cropReminders: boolean;
  };
}

const initialProfile: FarmerProfile = {
  id: '1',
  name: 'John Smith',
  email: 'john.smith@example.com',
  phone: '+1 (555) 123-4567',
  farmDetails: {
    name: 'Green Valley Farm',
    location: '123 Farm Road, Rural County',
    size: '50 acres',
    mainCrops: ['Tomatoes', 'Corn', 'Wheat'],
    yearEstablished: '2015',
  },
  notificationSettings: {
    marketUpdates: true,
    weatherAlerts: true,
    expertAdvice: true,
    cropReminders: false,
  },
};

export default function SettingsScreen() {
  const router = useRouter();
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [locationServices, setLocationServices] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [farmSize, setFarmSize] = useState(user?.farmDetails?.size || '');

  if (!user) {
    return (
      <View style={styles.container}>
        <Text>Please log in to view settings</Text>
      </View>
    );
  }

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleSaveFarmSize = async () => {
    try {
      if (user) {
        user.farmDetails = {
          ...user.farmDetails,
          size: farmSize,
        };
      }
      setEditMode(false);
      Alert.alert('Success', 'Farm size updated successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to update farm size');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account Information</Text>
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="person-outline" size={24} color="#666" />
            <View style={styles.settingText}>
              <Text style={styles.settingLabel}>Name</Text>
              <Text style={styles.settingValue}>{user.name}</Text>
            </View>
          </View>
        </View>
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="mail-outline" size={24} color="#666" />
            <View style={styles.settingText}>
              <Text style={styles.settingLabel}>Email</Text>
              <Text style={styles.settingValue}>{user.email}</Text>
            </View>
          </View>
        </View>
        {user.phoneNumber && (
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons name="call-outline" size={24} color="#666" />
              <View style={styles.settingText}>
                <Text style={styles.settingLabel}>Phone</Text>
                <Text style={styles.settingValue}>{user.phoneNumber}</Text>
              </View>
            </View>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Farm Details</Text>
        {user.farmName && (
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons name="business-outline" size={24} color="#666" />
              <View style={styles.settingText}>
                <Text style={styles.settingLabel}>Farm Name</Text>
                <Text style={styles.settingValue}>{user.farmName}</Text>
              </View>
            </View>
          </View>
        )}
        {user.region && (
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons name="location-outline" size={24} color="#666" />
              <View style={styles.settingText}>
                <Text style={styles.settingLabel}>Region</Text>
                <Text style={styles.settingValue}>{user.region}</Text>
              </View>
            </View>
          </View>
        )}
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="resize-outline" size={24} color="#666" />
            <View style={styles.settingText}>
              <Text style={styles.settingLabel}>Farm Size</Text>
              <Text style={styles.settingValue}>{user.farmDetails?.size || 'Not set'}</Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => setEditMode(true)}>
            <Ionicons name="create-outline" size={24} color="#4CAF50" />
          </TouchableOpacity>
        </View>
        {user.farmDetails?.mainCrops && user.farmDetails.mainCrops.length > 0 && (
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Ionicons name="leaf-outline" size={24} color="#666" />
              <View style={styles.settingText}>
                <Text style={styles.settingLabel}>Main Crops</Text>
                <View style={styles.cropTags}>
                  {user.farmDetails.mainCrops.map((crop) => (
                    <View key={crop} style={styles.cropTag}>
                      <Text style={styles.cropTagText}>{crop}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferences</Text>
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="notifications-outline" size={24} color="#666" />
            <Text style={styles.settingLabel}>Notifications</Text>
          </View>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={notifications ? '#fff' : '#f4f3f4'}
          />
        </View>
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="moon-outline" size={24} color="#666" />
            <Text style={styles.settingLabel}>Dark Mode</Text>
          </View>
          <Switch
            value={darkMode}
            onValueChange={setDarkMode}
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={darkMode ? '#fff' : '#f4f3f4'}
          />
        </View>
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="location-outline" size={24} color="#666" />
            <Text style={styles.settingLabel}>Location Services</Text>
          </View>
          <Switch
            value={locationServices}
            onValueChange={setLocationServices}
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={locationServices ? '#fff' : '#f4f3f4'}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Support</Text>
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="help-circle-outline" size={24} color="#666" />
            <Text style={styles.settingLabel}>Help & Support</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color="#666" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="document-text-outline" size={24} color="#666" />
            <Text style={styles.settingLabel}>Terms of Service</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color="#666" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Ionicons name="shield-outline" size={24} color="#666" />
            <Text style={styles.settingLabel}>Privacy Policy</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color="#666" />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={24} color="#fff" />
        <Text style={styles.logoutButtonText}>Log Out</Text>
      </TouchableOpacity>

      {/* Edit Farm Size Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={editMode}
        onRequestClose={() => setEditMode(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Farm Size</Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setEditMode(false)}
              >
                <Ionicons name="close" size={24} color="#666" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Farm Size</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter farm size (e.g., 50 acres)"
                value={farmSize}
                onChangeText={setFarmSize}
              />
            </View>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setEditMode(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleSaveFarmSize}
              >
                <Text style={styles.modalButtonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 20,
    padding: 15,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#e0e0e0',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 15,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingText: {
    marginLeft: 15,
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    color: '#333',
  },
  settingValue: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  cropTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  cropTag: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  cropTagText: {
    color: '#4CAF50',
    fontWeight: '500',
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f44336',
    margin: 20,
    padding: 15,
    borderRadius: 8,
  },
  logoutButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 12,
    width: '90%',
    maxWidth: 400,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  closeButton: {
    padding: 4,
  },
  modalBody: {
    padding: 16,
  },
  inputLabel: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  modalButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    minWidth: 80,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#e0e0e0',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  modalButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
