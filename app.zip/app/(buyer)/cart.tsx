import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  TextInput,
  ActivityIndicator,
  ImageBackground,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function CartScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { items, removeFromCart, updateQuantity, getTotalAmount, clearCart } = useCart();
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const handleCheckout = async () => {
    if (items.length === 0) {
      Alert.alert('Empty Cart', 'Please add items to your cart before checking out.');
      return;
    }

    setIsCheckingOut(true);
    try {
      // Create a new order
      const newOrder = {
        id: `#${Math.floor(Math.random() * 10000)}`,
        date: new Date().toISOString(),
        status: 'Processing',
        items: items.map(item => ({
          id: item.id,
          name: item.product.name,
          quantity: item.quantity,
          unit: item.product.unit,
          price: `BWP ${item.product.price.toFixed(2)}`,
          total: `BWP ${item.total.toFixed(2)}`,
          image: item.product.image
        })),
        subtotal: `BWP ${getTotalAmount().toFixed(2)}`,
        deliveryFee: 'BWP 50.00',
        total: `BWP ${(getTotalAmount() + 50).toFixed(2)}`,
        seller: {
          name: 'Multiple Sellers',
          image: require('../../assets/images/farm.png'),
          rating: 4.5,
          location: 'Gaborone, Botswana'
        },
        delivery: {
          address: user?.addresses?.[0]?.street || '123 Main Street, Gaborone',
          method: 'Standard Delivery',
          status: 'Preparing',
          estimatedDelivery: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        },
        payment: {
          method: user?.paymentMethods?.[0]?.type || 'Credit Card',
          last4: user?.paymentMethods?.[0]?.last4 || '4242',
          status: 'Paid'
        }
      };

      // Get existing orders or initialize empty array
      const existingOrdersJson = await AsyncStorage.getItem('orders');
      const existingOrders = existingOrdersJson ? JSON.parse(existingOrdersJson) : [];

      // Add new order to the beginning of the array
      const updatedOrders = [newOrder, ...existingOrders];

      // Save updated orders
      await AsyncStorage.setItem('orders', JSON.stringify(updatedOrders));

      // Clear the cart
      clearCart();

      // Show success message
      Alert.alert(
        'Order Placed Successfully',
        `Your order ${newOrder.id} has been placed and is being processed.`,
        [
          {
            text: 'View Order',
            onPress: () => router.push({
              pathname: "/(buyer)/order-details/[id]",
              params: { id: newOrder.id }
            })
          },
          {
            text: 'Continue Shopping',
            onPress: () => router.push('/(buyer)/market')
          }
        ]
      );
    } catch (error) {
      console.error('Checkout failed:', error);
      Alert.alert('Checkout Failed', 'There was an error processing your order. Please try again.');
    } finally {
      setIsCheckingOut(false);
    }
  };

  const renderCartItem = ({ item }) => (
    <View style={styles.cartItem}>
      <Image source={{ uri: item.product.image }} style={styles.productImage} />
      <View style={styles.itemDetails}>
        <Text style={styles.productName}>{item.product.name}</Text>
        <Text style={styles.productPrice}>BWP {item.product.price.toFixed(2)}/{item.product.unit}</Text>
        
        <View style={styles.quantityContainer}>
          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => {
              if (item.quantity > 1) {
                updateQuantity(item.product.id, item.quantity - 1);
              }
            }}
          >
            <Ionicons name="remove" size={20} color="#4CAF50" />
          </TouchableOpacity>
          
          <TextInput
            style={styles.quantityInput}
            value={item.quantity.toString()}
            onChangeText={(text) => {
              const newQuantity = parseInt(text) || 0;
              if (newQuantity > 0) {
                updateQuantity(item.product.id, newQuantity);
              }
            }}
            keyboardType="numeric"
          />
          
          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => updateQuantity(item.product.id, item.quantity + 1)}
          >
            <Ionicons name="add" size={20} color="#4CAF50" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.itemActions}>
        <Text style={styles.itemTotal}>BWP {item.total.toFixed(2)}</Text>
        <TouchableOpacity
          style={styles.removeButton}
          onPress={() => removeFromCart(item.product.id)}
        >
          <Ionicons name="trash-outline" size={24} color="#F44336" />
        </TouchableOpacity>
      </View>
    </View>
  );

  if (!user) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text>Loading cart...</Text>
      </View>
    );
  }

  return (
    <ImageBackground 
      source={require('../../assets/images/login-bg.jpg')}
      style={styles.backgroundImage}
    >
      <View style={styles.overlay}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Ionicons name="arrow-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.title}>Shopping Cart</Text>
          {items.length > 0 && (
            <TouchableOpacity 
              style={styles.clearButton}
              onPress={() => {
                Alert.alert(
                  'Clear Cart',
                  'Are you sure you want to clear your cart?',
                  [
                    { text: 'Cancel', style: 'cancel' },
                    { 
                      text: 'Clear',
                      style: 'destructive',
                      onPress: clearCart
                    }
                  ]
                );
              }}
            >
              <Ionicons name="trash-outline" size={24} color="#F44336" />
            </TouchableOpacity>
          )}
        </View>

        {items.length === 0 ? (
          <View style={styles.emptyCart}>
            <Ionicons name="cart-outline" size={64} color="#666" />
            <Text style={styles.emptyCartText}>Your cart is empty</Text>
            <TouchableOpacity
              style={styles.shopButton}
              onPress={() => router.push('/(buyer)/market')}
            >
              <Text style={styles.shopButtonText}>Start Shopping</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <FlatList
              data={items}
              renderItem={renderCartItem}
              keyExtractor={item => item.id}
              contentContainerStyle={styles.cartList}
            />
            
            <View style={styles.footer}>
              <View style={styles.totalContainer}>
                <Text style={styles.totalLabel}>Subtotal:</Text>
                <Text style={styles.totalAmount}>BWP {getTotalAmount().toFixed(2)}</Text>
              </View>
              <View style={styles.totalContainer}>
                <Text style={styles.totalLabel}>Delivery Fee:</Text>
                <Text style={styles.totalAmount}>BWP 50.00</Text>
              </View>
              <View style={[styles.totalContainer, styles.finalTotal]}>
                <Text style={styles.totalLabel}>Total:</Text>
                <Text style={styles.totalAmount}>BWP {(getTotalAmount() + 50).toFixed(2)}</Text>
              </View>
              
              <TouchableOpacity
                style={[
                  styles.checkoutButton,
                  isCheckingOut && styles.checkoutButtonDisabled
                ]}
                onPress={handleCheckout}
                disabled={isCheckingOut}
              >
                {isCheckingOut ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.checkoutButtonText}>Proceed to Checkout</Text>
                )}
              </TouchableOpacity>
            </View>
          </>
        )}
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  clearButton: {
    padding: 8,
  },
  emptyCart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyCartText: {
    fontSize: 18,
    color: '#666',
    marginTop: 16,
    marginBottom: 24,
  },
  shopButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  shopButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  cartList: {
    padding: 16,
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 12,
  },
  itemDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  productName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  productPrice: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityButton: {
    padding: 4,
    backgroundColor: '#f5f5f5',
    borderRadius: 4,
  },
  quantityInput: {
    width: 40,
    height: 32,
    textAlign: 'center',
    marginHorizontal: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
  },
  itemActions: {
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  itemTotal: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4CAF50',
    marginBottom: 8,
  },
  removeButton: {
    padding: 4,
  },
  footer: {
    backgroundColor: '#fff',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  totalLabel: {
    fontSize: 18,
    color: '#333',
  },
  totalAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  checkoutButton: {
    backgroundColor: '#4CAF50',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  checkoutButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  finalTotal: {
    borderTopWidth: 1,
    borderTopColor: '#eee',
    paddingTop: 12,
    marginTop: 8,
  },
  checkoutButtonDisabled: {
    backgroundColor: '#a5d6a7',
  }
}); 