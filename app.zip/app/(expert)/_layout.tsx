import { Stack } from 'expo-router';
import { useAuth } from '../../context/AuthContext';

export default function ExpertLayout() {
  const { user } = useAuth();

  if (!user || user.role !== 'expert') {
    return null; // Will be redirected by AuthContext
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: '#fff' },
      }}
    >
      <Stack.Screen name="index" />
      <Stack.Screen name="advice" />
      <Stack.Screen name="profile" />
      <Stack.Screen name="settings" />
    </Stack>
  );
} 